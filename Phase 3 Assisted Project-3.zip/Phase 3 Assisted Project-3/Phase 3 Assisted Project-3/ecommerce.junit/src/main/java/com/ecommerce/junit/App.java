package com.ecommerce.junit;

public class App {
    
    public static void main(String[] args) {
    }
    
}
